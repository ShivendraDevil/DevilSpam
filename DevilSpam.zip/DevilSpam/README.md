</p>
<p align="center">
<a href="https://bit.ly/2BNk3P1"><img title="Made in INDIA" src="https://img.shields.io/badge/BaapG-Attack-green.svg"></a>
<a href="https://bit.ly/2BNk3P1"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="https://bit.ly/2BNk3P1"><img title="Maintainence" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>
</p>
<p align="center">
</p>


<p align="center">

<img src="https://github.com/T-Dynamos/T-Dynamos/raw/main/bin/IMG_20211001_131953.jpg"/>




</p>





 


<p align="center">
<a href="https://github.com/T-Dynamos"><img title="Language" src="https://img.shields.io/badge/Made%20with-python3-1f425f.svg?v=103"></a>
<a href="https://github.com/T-Dynamos"><img title="Followers" src="https://img.shields.io/github/followers/T-Dynamos?color=blue&style=flat-square"></a>
<a href="https://github.com/T-Dynamos"><img title="Stars" src="https://img.shields.io/github/stars/T-Dynamos/BaapG-Attack?color=red&style=flat-square"></a>
<a href="https://github.com/T-Dynamos"><img title="Forks" src="https://img.shields.io/github/forks/T-Dynamos/BaapG-Attack?color=red&style=flat-square"></a>
<a href="https://github.com/T-Dynamos"><img title="Watching" src="https://img.shields.io/github/watchers/T-Dynamos/BaapG-Attack?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/T-Dynamos"><img title="Licence" src="https://img.shields.io/badge/License-MIT-blue.svg"></a>
</p>

## ABOUT TOOL :

BaapG-Attack is a python3 based script which is officially made for linux based distro . It is inbuit mass bomber with sms, mail, calls and many more bombing 
### We Need contributers for apidata

## AVAILABLE ON :

* Termux
* Kali Linux
* Debain Based

### TESTED ON :

* Termux
* Kali

### REQUIREMENTS :
* Python3

## FEATURES :
* [+] 99.99% Works!
* [+] Mass Bombing !
* [+] Tbomb api !
* [+] Easy for Beginners !

## INSTALLATION [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install git -y`
* `pip install lolcat`
* `git clone https://github.com/T-Dynamos/BaapG-Attack`
* `cd $HOME`
* `ls`
* `cd BaapG-Attack`
* `ls`
* `python3 BaapG.py`


## SCREEN SHOTS [Termux]

<br>
<p align="center">
<img width="50%" src="https://github.com/T-Dynamos/T-Dynamos/raw/main/bin/Screenshot_2021-10-01-13-03-59-944_com.termux.jpg"/>
<img width="45%" src="https://github.com/T-Dynamos/T-Dynamos/raw/main/bin/Screenshot_2021-10-01-13-19-08-100_com.termux.jpg"/>
</p>


## WARNING : 
This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.

## Dontaions

If You really like my work you should consider donating to me to made me buy [Raspberry Pi 400](https://www.electronicscomp.com/raspberry-pi-400-personal-keyboard-computer-kit)

* UPI ID : anshdadwal@apl
